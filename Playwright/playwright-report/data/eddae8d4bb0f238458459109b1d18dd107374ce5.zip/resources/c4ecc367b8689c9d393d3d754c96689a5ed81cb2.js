/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {
	"use strict";

	Drupal.behaviors.faculty_base = {
		attach: function (context, settings) {},
	};

	/* REJESTR ZMIAN */
	$(".toggle_record-link").click(function (event) {
		event.preventDefault();
		$(".toggle_record-box-two").toggleClass("toggle_record-hide");
		$(".toggle_record-description").toggleClass("toggle_record-active");
	});

	/*SCROLL NAV*/

	// $(window).scroll(function () {
	// 	if ( jQuery( '#page-wrapper' ).not( ".new-top" ).length > 0) {
	//
	// 		if ($(window).innerWidth() < 992 && window.scrollY > 160) {
	// 			$(".ug_navbar").css({top: "0", height: "80px"});
	// 			// $(".ug_navbar .container").addClass("pos-rel");
	// 			// $(".navbar-brand").addClass("m-reset");
	// 			$("#superfish-menu-glowne-toggle").attr("style", "top: -41px !important");
	// 		} else {
	// 			$(".ug_navbar").css({top: "0", height: "auto"});
	// 			// $(".ug_navbar .container").removeClass("pos-rel");
	// 			// $(".navbar-brand").removeClass("m-reset");
	// 			$("#superfish-menu-glowne-toggle").attr("style", "top:");
	// 		}
	//
	// 		if ($(window).innerWidth() > 992 && window.scrollY > 10) {
	// 			$(".ug_navbar").addClass("menu-fixed");
	// 			$("body").attr("style", "margin-top: 169px");
	// 			$(".menuglowne-desktop").attr("style", "border-bottom: none");
	// 		} else {
	// 			$(".ug_navbar").removeClass("menu-fixed");
	// 			$("body").attr("style", "margin-top: 0px");
	// 			$(".menuglowne-desktop").attr("style", "border-bottom: 1px solid #f0f0f0");
	// 		}
	// 		/*SCROLL top*/
	//
	// 		// if ($(this).scrollTop() < 200) {
	// 		// 	$('.top-arrow-btn').fadeOut();
	// 		// } else {
	// 		// 	$('.top-arrow-btn').fadeIn();
	// 		// }
	// 	}
	// });

	/* ADD COLOR TO TABLE WITHOUT THEAD */

	// if ($(".field--name-body table").has("thead").length > 0) {
	// 	$(".field--name-body table tbody tr").css({ color: "#141414" });
	// }
})(jQuery, Drupal);
